name             'magic'
version          File.read(File.join(File.dirname(__FILE__), 'VERSION')).strip
description      'Cookbook helpers and other magical things'
long_description 'Cookbook helpers and other magical things'
maintainer       'Sean Clemmer'
maintainer_email 'sczizzo@gmail.com'
license          'ISC'